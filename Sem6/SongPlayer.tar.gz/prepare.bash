sudo modprobe pcspkr
